import React from "react";
import Navbar from "../src/components/navbar/navbar"

function App() {
  const body = {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  }
  return (
    <div style={body} className="">
      <Navbar />
    </div>
  );
}

export default App;
