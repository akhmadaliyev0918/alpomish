import React, { useState } from 'react';
import logo from '../icons/edushoplogo.png'
import cartlogo from '../icons/cartlogo.png'
import personlogo from '../icons/personlogo.png'

import './style.css';

const Navbar = (props) => { 
    

    return (
        <div className='navbar'>
            <div className="navbarContainer">
                <button className='homeButton'>
                    <img src={logo} alt="Logo" />
                </button>
                <div className="searchContainer">
                    <input type="text" placeholder="Search for products..." />
                    <button className="searchButton"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                    </svg></button>
                </div>
                <div className="navbuttons">
                    <button id='cart'>
                        <img src={cartlogo} alt="" />
                        <span className="badge">0</span>
                    </button>
                    <button id='profile'><img src={personlogo} alt="" /></button>
                </div>
            </div>
            <div className="navbarCatalog"></div>
        </div>
    );
};

export default Navbar;
